# NovelReader
# A android app that lets you read Chinese ,Korean,Japanese novels in English Fan Translations
