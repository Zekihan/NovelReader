package com.zekihan.datatype;

@SuppressWarnings("unused")
public class DataModel {

    public final int icon;
    public final String name;

    public DataModel(int icon, String name) {

        this.icon = icon;
        this.name = name;
    }
}