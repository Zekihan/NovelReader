package com.zekihan.utilities;

public class Init {


}
