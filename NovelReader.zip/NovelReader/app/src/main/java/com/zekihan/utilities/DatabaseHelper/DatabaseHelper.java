package com.zekihan.utilities.DatabaseHelper;

public interface DatabaseHelper {
}
