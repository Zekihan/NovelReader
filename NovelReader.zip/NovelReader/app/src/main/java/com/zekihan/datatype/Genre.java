package com.zekihan.datatype;

public enum Genre {
    Action, Adventure, Celebrity, Comedy, Drama, Ecchi, Fantasy, Gender_Bender, Harem, Historical, Horror, Josei, Martial_Arts,
    Mature, Mecha, Mystery, Psychological, Romance, School_Life, Scifi, Seinen, Shotacon, Shoujo, Shoujo_Ai, Shounen, Shounen_Ai,
    Slice_of_Life, Smut, Sports, Supernatural, Tragedy, Wuxia, Xianxia, Xuanhuan, Yaoi, Yuri
}
