package com.zekihan.datatype;

public enum Status {
    Ongoing, Completed
}
